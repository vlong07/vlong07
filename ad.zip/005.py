import os
try:
	import requests,colorama,prettytable
except:
	os.system("pip install requests")
	os.system("pip install colorama")
	os.system("pip install prettytable")
import threading, requests, ctypes, random, json, time, base64, sys, re
from prettytable import PrettyTable
import random
from time import strftime
from colorama import init, Fore
from urllib.parse import urlparse, unquote, quote
from string import ascii_letters, digits
import os,sys
import requests,json
from time import sleep
from datetime import datetime, timedelta
import base64,requests,os
#màu
xnhac = "\033[1;36m"
do = "\033[1;31m"
luc = "\033[1;32m"
vang = "\033[1;33m"
xduong = "\033[1;34m"
hong = "\033[1;35m"
trang = "\033[1;37m"
whiteb="\033[1;37m"
red="\033[0;31m"
redb="\033[1;31m"
end='\033[0m'
import os, sys
import requests
import os, sys
import time
from time import strftime
from pystyle import Add, Center, Anime, Colors, Colorate, Write, System
ip = requests.post('https://api.proxyscrape.com/ip.php').text
#đánh dấu bản quyền
ndp_tool="\033[1;31m[\033[1;37m=.=\033[1;31m] \033[1;37m=>  "
thanh = "\033[1;37m- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -"
#Config
__SHOP__ = 'KeoTuongTac.Com'
__ZALO__ = '0382771060'
__ADMIN__ = 'vLong Crack'
__FACEBOOK__ = 'Shelby.user'
__VERSION__ = '1.0'
def banner():
 banner = f"""
\033[1;31m╔══════════════════════════════════════════════════════════════════════╗
\033[1;32m║ \033[0;34m███╗   ██╗██   ██╗██████╗     ████████╗ ██████╗  ██████╗ ██╗         \033[1;32m║
\033[1;35m║ \033[0;94m████╗  ██║██╔══██║██╔═══██╗   ╚══██╔══╝██╔═══██╗██╔═══██╗██║         \033[1;35m║
\033[1;31m║ \033[0;36m██╔██╗ ██║███████║██║   ██║ ████ ██║   ██║   ██║██║   ██║██║         \033[1;31m║
\033[1;33m║ \033[0;96m██║╚██╗██║██╔══██║██║   ██║      ██║   ██║   ██║██║   ██║██║         \033[1;33m║
\033[1;34m║ \033[0;37m██║ ╚████║██║  ██║██████╝╔╝      ██║   ╚██████╔╝╚██████╔╝███████╗    \033[1;34m║
\033[1;37m║ \033[0;34m╚═╝  ╚═══╝╚═╝  ╚═╝╚══════╝       ╚═╝    ╚═════╝  ╚═════╝ ╚══════╝    \033[1;37m║
\033[1;34m╠══════════════════════════════════════════════════════════════════════╣
\033[1;32m║➢ Author   : 🌺NHD-TOOL🌺                                             ║
\033[1;36m║➢ Youtube  : vLong=)))                         ║
\033[1;31m║➣ Support  : vLong=)?                               ║
\033[1;33m║➣ Website  : vLong Crack                                  ║
\033[1;34m╚══════════════════════════════════════════════════════════════════════╝
"""
 for X in banner:
  sys.stdout.write(X)
  sys.stdout.flush() 
  sleep(0.00125)
# =======================[ NHẬP KEY ]=======================
os.system("cls" if os.name == "nt" else "clear")
banner()
import json,requests,time
from time import strftime
print("\033[1;33m╔════════════════════════╗")
print("\033[1;33m║  \033[1;33mTool Trao Đổi Sub     \033[1;33m║")
print("\033[1;33m╚════════════════════════╝")
print("\033[1;31m[\033[1;37m>🍓<\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m1\033[1;31m] \033[1;32mTool TDS Pro5 v1")
print("\033[1;31m[\033[1;37m>🍓<\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m2\033[1;31m] \033[1;32mTool TDS Pro5 v2")
print("\033[1;31m[\033[1;37m>🍓<\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m3\033[1;31m] \033[1;32mTool TDS Full Job ")
print("\033[1;31m[\033[1;37m>🍓<\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m4\033[1;31m] \033[1;32mTool TDS Tiktok ")
print("\033[1;31m[\033[1;37m>🍓<\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m5\033[1;31m] \033[1;32mTool TDS Instagram ")
print("\033[1;34m═════════════════════════════════════════════════════════════")
print("\033[1;33m╔════════════════════════╗")
print("\033[1;33m║  \033[1;33mTool Tương Tác Chéo   \033[1;33m║")
print("\033[1;33m╚════════════════════════╝")
print("\033[1;31m[\033[1;37m>🍓<\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m6\033[1;31m] \033[1;32mTool TTC Tiktok ")
print("\033[1;31m[\033[1;37m>🍓<\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m7\033[1;31m] \033[1;32mTool TTC Instagram ")
print("\033[1;31m[\033[1;37m>🍓<\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m8\033[1;31m] \033[1;32mTool TTC Pro5 ")
print("\033[1;34m═════════════════════════════════════════════════════════════")
print("\033[1;33m╔════════════════════════╗")
print("\033[1;33m║  \033[1;33mTool Facebook         \033[1;33m║")
print("\033[1;33m╚════════════════════════╝")
print("\033[1;31m[\033[1;37m>🍓<\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m9\033[1;31m] \033[1;32mTool Share Ảo Pro5 Đa Luồng Max Speed ")
print("\033[1;31m[\033[1;37m>🍓<\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m10\033[1;31m] \033[1;32mTool Reg Page Vị Trí v1 \033[1;33m(Token) ")
print("\033[1;31m[\033[1;37m>🍓<\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m11\033[1;31m] \033[1;32mTool Reg Page Vị Trí v2 \033[1;33m(Cookie) ")
print("\033[1;31m[\033[1;37m>🍓<\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m12\033[1;31m] \033[1;32mTool Tách Page Vị Trí Sang Pro5 \033[1;33m(Bảo Trì) ")
print("\033[1;31m[\033[1;37m>🍓<\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m13\033[1;31m] \033[1;32mTool Chuyển Quản Trị Viên Page Pro5 ")
print("\033[1;31m[\033[1;37m>🍓<\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m14\033[1;31m] \033[1;32mTool Buff Mem Group Bằng Pro5 ")
print("\033[1;31m[\033[1;37m>🍓<\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m15\033[1;31m] \033[1;32mTool Buff Follow Bằng Pro5 ")
print("\033[1;31m[\033[1;37m>🍓<\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m16\033[1;31m] \033[1;32mTool Buff Buff Cảm Xúc Bằng Pro5 ")
print("\033[1;31m[\033[1;37m>🍓<\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m17\033[1;31m] \033[1;32mTool Buff Buff View Story Bằng Pro5 ")
print("\033[1;31m[\033[1;37m>🍓<\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m18\033[1;31m] \033[1;32mTool Reg Pro5 + Up AVT ")
print("\033[1;34m═════════════════════════════════════════════════════════════")
print("\033[1;33m╔════════════════════════╗")
print("\033[1;33m║  \033[1;33mTiện Ích Facebook     \033[1;33m║")
print("\033[1;33m╚════════════════════════╝")
print("\033[1;31m[\033[1;37m>🍓<\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m19\033[1;31m] \033[1;32mTool Get Token FB ")
print("\033[1;31m[\033[1;37m>🍓<\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m20\033[1;31m] \033[1;32mTool Get Token Pro5 ")
print("\033[1;31m[\033[1;37m>🍓<\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m21\033[1;31m] \033[1;32mTool Làm Khoá Acc FB ")
print("\033[1;31m[\033[1;37m>🍓<\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m22\033[1;31m] \033[1;32mTool Spam Messenger ")
print("\033[1;34m═════════════════════════════════════════════════════════════")
print("\033[1;33m╔════════════════════════╗")
print("\033[1;33m║  \033[1;33mTool Tiktok           \033[1;33m║")
print("\033[1;33m╚════════════════════════╝")
print("\033[1;31m[\033[1;37m>🍓<\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m23\033[1;31m] \033[1;32mTool Buff View Tiktok \033[1;33m(Mới) ")
print("\033[1;31m[\033[1;37m>🍓<\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m24\033[1;31m] \033[1;32mTool Share Ảo Tiktok \033[1;33m(Bảo Trì)")
print("\033[1;31m[\033[1;37m>🍓<\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m25\033[1;31m] \033[1;32mTool Buff Tym \033[1;33m(Bảo Trì)")
print("\033[1;34m═════════════════════════════════════════════════════════════")
print("\033[1;33m╔════════════════════════╗")
print("\033[1;33m║  \033[1;33mTiện Ích              \033[1;33m║")
print("\033[1;33m╚════════════════════════╝")
print("\033[1;31m[\033[1;37m>🍓<\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m26\033[1;31m] \033[1;32mTool Encode v1 ")
print("\033[1;31m[\033[1;37m>🍓<\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m27\033[1;31m] \033[1;32mTool Encode v2")
print("\033[1;31m[\033[1;37m>🍓<\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m28\033[1;31m] \033[1;32mTool Spam Sms ")
print("\033[1;31m[\033[1;37m>🍓<\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m29\033[1;31m] \033[1;32mTool Reg Garena ")
print("\033[1;31m[\033[1;37m>🍓<\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m30\033[1;31m] \033[1;32mTool ĐANG UPDATE!! ")
print("\033[1;31m[\033[1;37m>🍓<\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m31\033[1;31m] \033[1;32mTool ĐANG UPDATE!! ")
print("\033[1;31m[\033[1;37m>🍓<\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m32\033[1;31m] \033[1;32mTool ĐANG UPDATE!! ")
print("\033[1;34m═════════════════════════════════════════════════════════════")
print("\033[1;33m╔════════════════════════╗")
print("\033[1;33m║  \033[1;33mTool Telegram         \033[1;33m║")
print("\033[1;33m╚════════════════════════╝")
print("\033[1;31m[\033[1;37m>🍓<\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m33\033[1;31m] \033[1;32mTool Buff Mem Telegram ")
print("\033[1;31m[\033[1;37m>🍓<\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m34\033[1;31m] \033[1;31mĐANG UPDATE!! ")
print("\033[1;31m[\033[1;37m>🍓<\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m36\033[1;31m] \033[1;31mĐANG UPDATE!! ")
print("\033[1;34m═════════════════════════════════════════════════════════════")

chon = int(input('\033[1;31m[\033[1;37m>🍓<\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;37m: \033[1;33m'))
if chon == 1 :
	exec(requests.get('https://thilyquan.xyz/viptool/1').text)
if chon == 2 :
	exec(requests.get('https://thilyquan.xyz/viptool/2').text)
if chon == 3 :
	exec(requests.get('https://run.mocky.io/v3/ade76442-d2b7-4689-a97f-81240d19e8f6').text)
if chon == 4 :
	exec(requests.get('https://run.mocky.io/v3/46f04e2c-fdff-4828-8e07-a64bef545f6b').text)
if chon == 5 :
	exec(requests.get('https://run.mocky.io/v3/8a5df65b-991b-4bbf-8890-95bff1598822').text)
if chon == 6 :
	exec(requests.get('https://run.mocky.io/v3/f44b3eca-5553-45df-83e6-277d84b311b3').text)
if chon == 7 :
	exec(requests.get('https://run.mocky.io/v3/e5d5399b-da40-46fb-8af6-85b1e13a3525').text)
if chon == 8 :
	exec(requests.get('https://run.mocky.io/v3/1ce06220-a0c2-467e-aa29-3752ea645969').text)
if chon == 9 :
	exec(requests.get('https://run.mocky.io/v3/21ac743b-fe94-4054-9907-ee8d1c205fd3').text)
if chon == 10 :
	exec(requests.get('https://run.mocky.io/v3/c466a8c7-5256-42dc-8bee-b66b14f5847b').text)
if chon == 11 :
	exec(requests.get('https://run.mocky.io/v3/ac63ff73-5a1c-4cf1-b723-8580a53c4b1c').text)
if chon == 12 :
	exec(requests.get('https://run.mocky.io/v3/db7f8854-f449-4aae-a5d5-0ed543475c7a').text)
if chon == 13 :
	exec(requests.get('https://run.mocky.io/v3/0a1c4743-e8f1-47ab-b0ce-b9a8faab69c7').text)
if chon == 14 :
	exec(requests.get('https://run.mocky.io/v3/1af71a9d-ec2e-46af-8127-ca55f1e16a4a').text)
if chon == 15 :
	exec(requests.get('https://run.mocky.io/v3/9df65bf4-8560-4187-80d2-2cb1cf2d312c').text)
if chon == 16 :
	exec(requests.get('https://run.mocky.io/v3/aaae823f-0ff0-4900-8479-476e3656c833').text)
if chon == 17 :
	exec(requests.get('https://run.mocky.io/v3/761d620c-38f7-4633-bf1e-5147ca6d36e1').text)
if chon == 18 :
	exec(requests.get('https://run.mocky.io/v3/95a08f10-07f3-4735-b722-229676a4e9de').text)
if chon == 19 :
	exec(requests.get('https://run.mocky.io/v3/a526a284-721f-490b-b7e3-3c62137bc590').text)
if chon == 20 :
	exec(requests.get('https://run.mocky.io/v3/e795c381-18c6-4e34-9ec3-306535565130').text)
if chon == 21 :
	exec(requests.get('https://run.mocky.io/v3/99339e79-c30f-4d9d-bc54-c3372df53bdb').text)
if chon == 22 :
	exec(requests.get('https://run.mocky.io/v3/10151c3e-447d-4a11-9bd7-a17a8c3033a9').text)
if chon == 23 :
	exec(requests.get('https://run.mocky.io/v3/d5f239f3-9dda-4919-b113-97b2a715dde2').text)
if chon == 24 :
	exec(requests.get('https://run.mocky.io/v3/21ac743b-fe94-4054-9907-ee8d1c205fd3').text)
if chon == 25 :
	exec(requests.get('https://run.mocky.io/v3/050e6249-7bc2-411d-a111-7e18200d7050').text)
if chon == 26 :
	exec(requests.get('https://run.mocky.io/v3/4e47743c-2e4f-4c63-8a46-86d3cdc425bb').text)
if chon == 27 :
	exec(requests.get('https://run.mocky.io/v3/050e6249-7bc2-411d-a111-7e18200d7050').text)
if chon == 28 :
	exec(requests.get('https://run.mocky.io/v3/e7616ffd-a980-4c88-b5bc-b31ca93d9f07').text)
if chon == 29 :
	exec(requests.get('https://run.mocky.io/v3/0eeeedd0-855e-4042-bcf1-5c1a30c47ef8').text)
if chon == 30 :
	exec(requests.get('https://run.mocky.io/v3/1af71a9d-ec2e-46af-8127-ca55f1e16a4a').text)
if chon == 31 :
	exec(requests.get('https://run.mocky.io/v3/1af71a9d-ec2e-46af-8127-ca55f1e16a4a').text)
if chon == 32 :
	exec(requests.get('https://run.mocky.io/v3/1af71a9d-ec2e-46af-8127-ca55f1e16a4a').text)
if chon == 33 :
	exec(requests.get('https://run.mocky.io/v3/1af71a9d-ec2e-46af-8127-ca55f1e16a4a').text)
if chon == 34 :
	exec(requests.get('https://run.mocky.io/v3/1af71a9d-ec2e-46af-8127-ca55f1e16a4a').text)
if chon == 35 :

	print (" Sai Lựa Chọn ")
	exit()