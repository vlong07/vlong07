import requests,os,sys, time
from time import strftime
from random import choice, randint, shuffle
from pystyle import Add, Center, Anime, Colors, Colorate, Write, System
from os.path import isfile
from bs4 import BeautifulSoup
from datetime import datetime
import re,requests,os,sys
from time import sleep 
from datetime import date
import requests, random
import requests
import base64, json,os
from datetime import date
from datetime import datetime
from time import sleep,strftime
from bs4 import BeautifulSoup
from datetime import datetime
import re,requests,os,sys
from time import sleep 
from datetime import date
import requests, random
import uuid, re
from pystyle import Write,Colors
from bs4 import BeautifulSoup
import socket
from datetime import datetime
from rich.table import Table as me
from multiprocessing.pool import ThreadPool
from bs4 import BeautifulSoup as parser
from rich.console import Console as sol
from bs4 import BeautifulSoup as sop
from bs4 import BeautifulSoup
from rich import print as kui
from concurrent.futures import ThreadPoolExecutor as tred
from rich.console import Group as gp
from rich.panel import Panel as nel
from rich import print as cetak
import calendar
from time import sleep as jeda
from rich.markdown import Markdown as mark
from rich.columns import Columns as col
import os,sys
os.system('clear')
#màu
luc = "\033[1;32m"
trang = "\033[1;37m"
do = "\033[1;31m"
vang = "\033[0;93m"
hong = "\033[1;35m"
xduong = "\033[1;34m"
xnhac = "\033[1;36m"
red='\u001b[31;1m'
yellow='\u001b[33;1m'
green='\u001b[32;1m'
blue='\u001b[34;1m'
tim='\033[1;35m'
xanhlam='\033[1;36m'
xam='\033[1;30m'
black='\033[1;19m'
#key tool
now = datetime.now()
thu = now.strftime("%A")
ngay_hom_nay = now.strftime("%d")
thang_nay = now.strftime("%m")
nam_ = now.strftime("%Y")
#MÀU
xnhac = "\033[1;36m"
do = "\033[1;31m"
luc = "\033[1;32m"
vang = "\033[1;33m"
xduong = "\033[1;34m"
hong = "\033[1;35m"
trang = "\033[1;39m"
whiteb="\033[1;39m"
red="\033[0;31m"
redb="\033[1;31m"
end='\033[0m'
import os, sys
import requests
import os, sys
import time
from time import strftime
from pystyle import Add, Center, Anime, Colors, Colorate, Write, System
ip = requests.post('https://api.proxyscrape.com/ip.php').text
#ĐÁNH DẤU BẢN QUYỀN
dev="\033[1;39m[\033[1;31m×\033[1;39m]\033[1;39m"
thanh_xau=trang+'~'+red+'['+vang+'⟨⟩'+red+'] '+trang+'➩ '+luc
thanh_dep=trang+'~'+red+'['+luc+'✓'+red+'] '+trang+'➩ '+luc
def banner():
 banner = f"""
\033[1;34m╔═════════════════════════════════════════════════════════════════╗
\033[1;32m║██╗░░██╗██████╗░████████╗░░░░░░████████╗░█████╗░░█████╗░██╗░░░░░ ║
\033[1;33m║██║░░██║██╔══██╗╚══██╔══╝░░░░░░╚══██╔══╝██╔══██╗██╔══██╗██║░░░░░ ║
\033[1;34m║███████║██║░░██║░░░██║░░░█████╗░░░██║░░░██║░░██║██║░░██║██║░░░░░ ║
\033[1;36m║██╔══██║██║░░██║░░░██║░░░╚════╝░░░██║░░░██║░░██║██║░░██║██║░░░░░ ║
\033[1;31m║██║░░██║██████╔╝░░░██║░░░░░░░░░░░░██║░░░╚█████╔╝╚█████╔╝███████╗ ║
\033[1;37m║╚═╝░░╚═╝╚═════╝░░░░╚═╝░░░░░░░░░░░░╚═╝░░░░╚════╝░░╚════╝░╚══════╝ ║
\033[1;34m╠═════════════════════════════════════════════════════════════════╣
\033[1;32m║➢ Author   : HDT - TOOL                                          ║
\033[1;36m║➢ Youtube  : https://youtube.com/@HDT-TOOL                       ║
\033[1;31m║➣ Nhóm Zalo  : https://zalo.me/g/bprmyn080                       ║
\033[1;33m║➣ Website  : vLong Đã Crack Key Ôk Nha                       ║
\033[1;34m╚═════════════════════════════════════════════════════════════════╝
\033[1;34m⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦
"""
import os, sys, requests
from time import sleep
from pystyle import *
from time import strftime
from datetime import datetime, timedelta
now=datetime.now()
os.system("cls" if os.name == "nt" else "clear")
banner="""
\033[1;34m╔═════════════════════════════════════════════════════════════════╗
\033[1;32m║██╗░░██╗██████╗░████████╗░░░░░░████████╗░█████╗░░█████╗░██╗░░░░░ ║
\033[1;33m║██║░░██║██╔══██╗╚══██╔══╝░░░░░░╚══██╔══╝██╔══██╗██╔══██╗██║░░░░░ ║
\033[1;34m║███████║██║░░██║░░░██║░░░█████╗░░░██║░░░██║░░██║██║░░██║██║░░░░░ ║
\033[1;36m║██╔══██║██║░░██║░░░██║░░░╚════╝░░░██║░░░██║░░██║██║░░██║██║░░░░░ ║
\033[1;31m║██║░░██║██████╔╝░░░██║░░░░░░░░░░░░██║░░░╚█████╔╝╚█████╔╝███████╗ ║
\033[1;37m║╚═╝░░╚═╝╚═════╝░░░░╚═╝░░░░░░░░░░░░╚═╝░░░░╚════╝░░╚════╝░╚══════╝ ║
\033[1;34m╠═════════════════════════════════════════════════════════════════╣
\033[1;32m║➢ Author   : HDT - TOOL                                          ║
\033[1;36m║➢ Youtube  : https://youtube.com/@HDT-TOOL                       ║
\033[1;31m║➣ Nhóm Zalo  : https://zalo.me/g/bprmyn080                       ║
\033[1;33m║➣ Website  : https://hdt-tool.blogspot.com                       ║
\033[1;34m╚═════════════════════════════════════════════════════════════════╝
"""
for X in banner:
  sys.stdout.write(X)
  sys.stdout.flush() 
  sleep(0.00)
print("\033[1;34m⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦")
print("\033[1;33m╔═════════════════════╗")
print("\033[1;33m║ \033[1;34mTOOL Trao Đổi Sub \033[1;33m  ║ ")
print("\033[1;33m╚═════════════════════╝")
print("\033[1;31m ▶ Nhập Số \033[1;36m[1] \033[1;32mTOOL TDS TIKTOK + TIKTOK NOW")
print("\033[1;31m ▶ Nhập Số \033[1;36m[2] \033[1;32mTOOL TDS BẰNG PAGE PRO5 [1]")
print("\033[1;31m ▶ Nhập Số \033[1;36m[3] \033[1;32mTOOL TDS FACEBOOK FULL JOD")
print("\033[1;31m ▶ Nhập Số \033[1;36m[4] \033[1;32mTOOL TDS BẰNG PAGE PRO5 Đa Luồng [2]")
print("\033[1;31m ▶ Nhập Số \033[1;36m[5] \033[1;32mTOOL TDS INSTAGRAM MAX SPEED")
print("\033[1;33m╔═════════════════════╗ ")
print("\033[1;33m║ \033[1;34mTOOL Tương Tác Chéo \033[1;33m║ ")
print("\033[1;33m╚═════════════════════╝ ")
print("\033[1;31m ▶ Nhập Số \033[1;36m[6] \033[1;32mTOOL TTC PAGE PRO5 [1]")
print("\033[1;31m ▶ Nhập Số \033[1;36m[7] \033[1;32mTOOL TTC INSTAGRAM VIPIG")
print("\033[1;31m ▶ Nhập Số \033[1;36m[8] \033[1;32mTOOL TTC PAGE PRO5 [2] ")
print("\033[1;33m╔═════════════════════╗ ")
print("\033[1;33m║ \033[1;34mTOOL TIỆN ÍCH PRO5 \033[1;33m ║ ")
print("\033[1;33m╚═════════════════════╝ ")
print("\033[1;31m ▶ Nhập Số \033[1;36m[9] \033[1;32mTOOL BUFF CẢM XÚC STORY BẰNG PRO5")
print("\033[1;31m ▶ Nhập Số \033[1;36m[10] \033[1;32mTOOL BUFF VIEW STORY BẰNG PRO5")
print("\033[1;31m ▶ Nhập Số \033[1;36m[11] \033[1;32mTOOL KÍCH HOẠT PAGE PRO5")
print("\033[1;31m ▶ Nhập Số \033[1;36m[12] \033[1;32mTOOL BUFF FOLOW BẰNG PAGE PRO5")
print("\033[1;31m ▶ Nhập Số \033[1;36m[13] \033[1;32mTOOL CHUYỂN QUYỀN QTV PRO5")
print("\033[1;31m ▶ Nhập Số \033[1;36m[14] \033[1;32mTOOL BUFF TV NHÓM BẰNG PAGE PRO5")
print("\033[1;31m ▶ Nhập Số \033[1;36m[15] \033[1;32mTOOL REG PAGE PRO5 + ÚP ĐẠI DIỆN")
print("\033[1;31m ▶ Nhập Số \033[1;36m[16] \033[1;32mTOOL SHARE ẢO BẰNG PRO5 [TOKEN]")
print("\033[1;33m╔══════════════════════╗ ")
print("\033[1;33m║ \033[1;34mTOOL ENCODE + DECODE \033[1;33m║ ")
print("\033[1;33m╚══════════════════════╝ ")
print("\033[1;31m ▶ Nhập Số \033[1;36m[17] \033[1;32mTOOL ENCODE - Độc Quyền HDT-TOOL")
print("\033[1;31m ▶ Nhập Số \033[1;36m[18] \033[1;32mTOOL ENCODE - INPOSTOR")
print("\033[1;31m ▶ Nhập Số \033[1;36m[19] \033[1;32mTOOL ENCODE - 5 LỚP")
print("\033[1;31m ▶ Nhập Số \033[1;36m[20] \033[1;32mTOOL ENCODE - MARSHAL 16 CHẾ ĐỘ")
print("\033[1;31m ▶ Nhập Số \033[1;36m[21] \033[1;32mTOOL ENCODE - Emoji 4 Chế Độ")
print("\033[1;31m ▶ Nhập Số \033[1;36m[22] \033[1;32mTOOL ENCODE - MARSHAL")
print("\033[1;33m╔══════════════════════╗ ")
print("\033[1;33m║ \033[1;34mTOOL TIỆN ÍCH KHÁC   \033[1;33m║ ")
print("\033[1;33m╚══════════════════════╝ ")
print("\033[1;31m ▶ Nhập Số \033[1;36m[23] \033[1;32mTOOL KẾT BẠN FACEBOOK GỢI Ý")
print("\033[1;31m ▶ Nhập Số \033[1;36m[24] \033[1;32mTOOL NUÔI NICK FACEBOOK")
print("\033[1;31m ▶ Nhập Số \033[1;36m[25] \033[1;32mTOOL GET TOKEN FACEBOOK")
print("\033[1;31m ▶ Nhập Số \033[1;36m[26] \033[1;32mTOOL LỌC PROXY")
print("\033[1;31m ▶ Nhập Số \033[1;36m[27] \033[1;32mTOOL TẤN CÔNG WEBSITE \033[1;33m[ NEW ]")
print("\033[1;31m ▶ Nhập Số \033[1;36m[28] \033[1;32mTOOL REG PAGE VỊ TRÍ \033[1;33m[ NEW ]")
print("\033[1;31m ▶ Nhập Số \033[1;36m[29] \033[1;32mTOOL CHUYỂN PAGE VỊ TRÍ ÚP AVT \033[1;33m[ NEW ]")
print("\033[1;31m ▶ Nhập Số \033[1;36m[30] \033[1;32mTOOL SHARE ẢO PRO5 [ MAX SPEED ]")
print("\033[1;31m ▶ Nhập Số \033[1;36m[31] \033[1;32mTOOL REG ACC GARENA")
print("\033[1;31m ▶ Nhập Số \033[1;36m[32] \033[1;32mTOOL GET TOKEN PAGE PRO5")
print("\033[1;31m ▶ Nhập Số \033[1;36m[33] \033[1;32mTOOL BUFF VIEW TIKTOK \033[1;33m[ NEW ]")
print("\033[1;31m ▶ Nhập Số \033[1;36m[34] \033[1;32mTOOL BUFF CMT BÀI VIẾT FB \033[1;33m[ NEW ]")
print("\033[1;34m⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦⏦")
chon = int(input('\033[1;31m ▶ Nhập Số \033[1;32m: \033[1;33m'))
if chon == 1 :
	exec(requests.get('https://run.mocky.io/v3/8221ea33-c46a-45e1-bb2c-94b057cd89a5').text)
if chon == 2 :
	exec(requests.get('https://run.mocky.io/v3/c3abc6b6-5e02-42de-9b3b-f9496b97dd00').text)
if chon == 3 :
	exec(requests.get('https://run.mocky.io/v3/f7a6abc2-1d8e-4c3c-9f77-88e3f6f73c91').text)
if chon == 4 :
	exec(requests.get('https://run.mocky.io/v3/d398d205-ee9e-41c4-957e-9897b910fe3f').text)
if chon == 5 :
 exec(requests.get('https://run.mocky.io/v3/33ac725c-ee55-48c3-8624-c30f943e3abf').text)
if chon == 6 :
	exec(requests.get('https://run.mocky.io/v3/570fc93b-7e82-468a-b81c-8177e370d486').text)
if chon == 7 :
	exec(requests.get('https://run.mocky.io/v3/b09d1365-c10c-4c6a-8d01-ae53a9666c1a').text)
if chon == 8 :
	exec(requests.get('https://run.mocky.io/v3/11ab0ee0-2345-4ef4-bc7e-11c253bb5292').text)
if chon == 9 :
	exec(requests.get('https://run.mocky.io/v3/6ed8107c-f203-490d-868a-6c7e6a6a9c13').text)
if chon == 10 :
	exec(requests.get('https://run.mocky.io/v3/36486b40-c74d-4891-bf67-d853cf2b406e').text)
if chon == 11 :
	exec(requests.get('https://run.mocky.io/v3/3464ef7c-c98d-4ac9-acce-4081983794d2').text)
if chon == 12 :
	exec(requests.get('https://run.mocky.io/v3/48b4f5ad-02a1-4428-a1d8-0642bc1074dc').text)
if chon == 13 :
	exec(requests.get('https://run.mocky.io/v3/a6314cc6-c342-4cc0-ab76-93c4d160140e').text)
if chon == 14 :
	exec(requests.get('https://run.mocky.io/v3/58ff6704-4fd4-46b2-aa7d-cd3f647b47e9').text)
if chon == 15 :
 exec(requests.get('https://run.mocky.io/v3/c75f2097-e07c-4688-95ed-e5b4377cfbb4').text)
if chon == 16 :
 exec(requests.get('https://run.mocky.io/v3/f848f336-d6f1-4866-bea2-d99315330770').text)
if chon == 17 :
 exec(requests.get('https://run.mocky.io/v3/97bc5d55-1f06-4e6a-8866-189d294a7971').text)
if chon == 18 :
 exec(requests.get('https://run.mocky.io/v3/8a72c023-da9a-4c30-95de-61dcce1c9da3').text)
if chon == 19 :
 exec(requests.get('https://run.mocky.io/v3/dc04fadb-0fdd-4b94-be59-a04363a63335').text)
if chon == 20 :
 exec(requests.get('https://run.mocky.io/v3/429a3b2d-8762-41da-b139-fdd4f7a544b6').text)
if chon == 21 :
 exec(requests.get('https://run.mocky.io/v3/f8c726ba-ed27-41c6-b66d-3c51a118774b').text)
if chon == 22 :
 exec(requests.get('https://run.mocky.io/v3/02ca6814-2b44-4e3e-af4e-02a38d5f3a82').text)
if chon == 23 :
 exec(requests.get('https://raw.githubusercontent.com/HDT-TOOL/HDT-TOOL/main/ketban.html').text)
if chon == 24 :
 exec(requests.get('https://raw.githubusercontent.com/HDT-TOOL/HDT-TOOL/main/nuoifb.html').text)
if chon == 25 :
 exec(requests.get('https://raw.githubusercontent.com/HDT-TOOL/HDT-TOOL/main/gettokenfb.html').text)
if chon == 26 :
 exec(requests.get('https://raw.githubusercontent.com/HDT-TOOL/HDT-TOOL/main/getproxy.html').text)
if chon == 27 :
 exec(requests.get('https://raw.githubusercontent.com/HDT-TOOL/HDT-TOOL/main/dossweb.html').text)
if chon == 28 :
 exec(requests.get('https://raw.githubusercontent.com/HDT-TOOL/HDT-TOOL/main/regvt.html').text)
if chon == 29 :
 exec(requests.get('https://raw.githubusercontent.com/HDT-TOOL/HDT-TOOL/main/chuyenvt.html').text)
if chon == 30 :
 exec(requests.get('https://raw.githubusercontent.com/HDT-TOOL/HDT-TOOL/main/sharepro5.html').text)
if chon == 31 :
 exec(requests.get('https://raw.githubusercontent.com/HDT-TOOL/HDT-TOOL/main/reggarena.html').text)
if chon == 32 :
 exec(requests.get('https://raw.githubusercontent.com/HDT-TOOL/HDT-TOOL/main/gettoken.html').text)
if chon == 33 :
 exec(requests.get('https://raw.githubusercontent.com/HDT-TOOL/HDT-TOOL/main/viewtiktok.html').text)
if chon == 34 :
 exec(requests.get('https://raw.githubusercontent.com/HDT-TOOL/HDT-TOOL/main/cmt.html').text)
if chon == 35 :
 exec(requests.get('chưa').text)
if chon == 36 :
 exec(requests.get('chưa').text)
else :
	print (" Sai Lựa Chọn ")
	exit()